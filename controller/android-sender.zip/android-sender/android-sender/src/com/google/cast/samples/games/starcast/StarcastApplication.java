
package com.google.cast.samples.games.starcast;

import android.app.Application;

/**
 * The application class.
 */
public class StarcastApplication extends Application
        implements CastConnectionManager.CastAppIdProvider {

    private static StarcastApplication sInstance;

    private CastConnectionManager mCastConnectionManager;
    private SendMessageHandler mSendMessageHandler;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        mCastConnectionManager = new CastConnectionManager(this, this);
        mSendMessageHandler = new SendMessageHandler(mCastConnectionManager);
    }

    public static StarcastApplication getInstance() {
        return sInstance;
    }

    public CastConnectionManager getCastConnectionManager() {
        return mCastConnectionManager;
    }

    public SendMessageHandler getSendMessageHandler() {
        return mSendMessageHandler;
    }

    @Override
    public String getCastAppId() {
        return getResources().getString(R.string.app_id);
    }
}
